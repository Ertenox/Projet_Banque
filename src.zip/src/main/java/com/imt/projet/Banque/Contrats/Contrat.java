package com.imt.projet.Banque.Contrats;
import com.imt.projet.Banque.Clients;

import java.util.Date;
import java.util.UUID;

public interface Contrat {
    UUID getId();
    String getType();
    Date getDate();
    Clients getClient();
    Double getInteret();
    Double getBalance();
}
