package com.imt.projet.Banque;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BanqueApplicationTests {

	@Test
	void contextLoads() {
	}

}
